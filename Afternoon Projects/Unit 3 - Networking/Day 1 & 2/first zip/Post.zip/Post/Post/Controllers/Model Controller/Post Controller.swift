//
//  Post Controller.swift
//  Post
//
//  Created by Deniz Tutuncu on 2/4/19.
//  Copyright © 2019 DevMtnStudent. All rights reserved.
//

import Foundation

class PostController {
    
    let baseURL = URL(string: "https://devmtn-posts.firebaseio.com/posts")
    
    var posts: [Post] = []
    var postData: Data?
    
    func fetchPosts(completion: @escaping () -> Void) {
        
        guard let unwrappedURL = baseURL else { fatalError("URL optional is having issues") }
        let getterEndpoint = unwrappedURL.appendingPathExtension("json")
        
        var urlRequest = URLRequest(url: getterEndpoint)
        print(urlRequest)
        urlRequest.httpBody = nil
        urlRequest.httpMethod = "GET"
        
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, _, error) in
            do {
                if let downloadError = error { throw downloadError }
                guard let data = data else { throw NSError() }
                //Decode
                let jsonDecoder = JSONDecoder()
                let postsDictionary = try! jsonDecoder.decode([String:Post].self, from: data)
                var posts  = postsDictionary.compactMap({ $0.value })
                posts.sort(by: {$0.timestamp > $1.timestamp })
                print(posts)
                self.posts = posts
                completion()
                return
                
            } catch {
                print("\(error.localizedDescription)")
            }
        }
        dataTask.resume()
    }
    
    
    func addNewPostWith(username: String, text: String, completion: @escaping (() -> Void)) {
        
    }
}
