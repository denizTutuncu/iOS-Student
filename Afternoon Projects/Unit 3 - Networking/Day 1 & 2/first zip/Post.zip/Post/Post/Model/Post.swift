//
//  Post.swift
//  Post
//
//  Created by Deniz Tutuncu on 2/4/19.
//  Copyright © 2019 DevMtnStudent. All rights reserved.
//

import Foundation

struct Post: Codable {
    let text: String
    let timestamp: TimeInterval = Date().timeIntervalSince1970
    let username: String
}

let postOne = Post(text: "a post", username: "deniz")


